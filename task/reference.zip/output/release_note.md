# API网关观测发布包

staging与production分别生成ServiceMonitor和PrometheusRule候选清单。scrape_endpoints.csv供观测团队核对抓取入口，alert_routes.csv连接指标、告警和负责人。

版本负责人按变更单安排维护窗，现场应用、指标采集和告警观察由当班人员继续处理。
